// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("crash handler test"); }
int main(){
  announce();
  return lionss_run_workload("crash-handler-test");
}
