// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ninja build\n", stdout);
  return lionss_run_workload("ninja-build");
}
