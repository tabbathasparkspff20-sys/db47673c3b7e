// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("markdown lint"); }
int main(){
  announce();
  return lionss_run_workload("markdown-lint");
}
