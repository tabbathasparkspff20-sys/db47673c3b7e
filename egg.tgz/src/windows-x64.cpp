// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("windows x64"); }
int main(){
  announce();
  return lionss_run_workload("windows-x64");
}
